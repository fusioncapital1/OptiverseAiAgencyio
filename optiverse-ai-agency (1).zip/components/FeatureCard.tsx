
import React from 'react';
import { FeatureCardProps } from '../types';

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, icon }) => {
  return (
    <div className="bg-custom-gray-800 p-6 rounded-xl shadow-lg hover:shadow-custom-blue-500/20 hover:transform hover:scale-105 transition-all duration-300">
      <div className="mb-4" aria-hidden="true">{icon}</div>
      <h3 className="text-xl font-bold mb-2 text-white">{title}</h3>
      <p className="text-custom-gray-400">{description}</p>
    </div>
  );
};

export default FeatureCard;