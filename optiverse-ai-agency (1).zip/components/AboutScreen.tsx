
import React from 'react';
import TeamMember from './TeamMember';

const AboutScreen: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-10" aria-labelledby="about-screen-heading">
      <h2 id="about-screen-heading" className="text-3xl md:text-4xl font-bold text-center text-white">About AI Lock Picks</h2>
      
      <section className="bg-custom-gray-800 rounded-xl p-6 md:p-8 shadow-lg" aria-labelledby="our-mission-heading">
        <h3 id="our-mission-heading" className="text-2xl font-bold mb-4 text-custom-blue-400">Our Mission</h3>
        <p className="text-custom-gray-300 mb-4 leading-relaxed">
          At AI Lock Picks, we're revolutionizing sports betting through cutting-edge artificial intelligence technology. Our mission is to empower bettors with data-driven insights that combine the power of machine learning with deep sports analytics.
        </p>
        <p className="text-custom-gray-300 leading-relaxed">
          We believe that successful sports betting should be about informed decision-making rather than pure luck. By leveraging advanced algorithms and real-time data processing, we provide users with actionable insights that dramatically improve their chances of winning.
        </p>
      </section>
      
      <section className="grid md:grid-cols-2 gap-6">
        <div className="bg-custom-gray-800 rounded-xl p-6 shadow-lg" aria-labelledby="tech-stack-heading">
          <h3 id="tech-stack-heading" className="text-xl font-bold mb-4 text-custom-blue-400">Technology Stack</h3>
          <ul className="space-y-3 text-custom-gray-300">
            {[
              "Neural networks for pattern recognition",
              "Real-time data ingestion pipelines",
              "Probability calculation engine",
              "Dynamic odds comparison",
              "Parlay optimization algorithms"
            ].map((item, index) => (
              <li key={index} className="flex items-start">
                <span className="flex-shrink-0 w-2.5 h-2.5 bg-custom-blue-400 rounded-full mr-3 mt-1.5" aria-hidden="true"></span>
                {item}
              </li>
            ))}
          </ul>
        </div>
        
        <div className="bg-custom-gray-800 rounded-xl p-6 shadow-lg" aria-labelledby="sports-coverage-heading">
          <h3 id="sports-coverage-heading" className="text-xl font-bold mb-4 text-custom-blue-400">Sports Coverage</h3>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-custom-gray-300">
            {["NBA", "NFL", "MLB", "NHL", "Premier League", "Tennis Grand Slams"].map((sport, index) => (
               <div key={index} className="flex items-center">
                <span className="w-2 h-2 bg-custom-blue-400 rounded-full mr-2" aria-hidden="true"></span>
                {sport}
              </div>
            ))}
          </div>
          
          <div className="mt-6 pt-4 border-t border-custom-gray-700">
            <h4 className="font-semibold mb-3 text-custom-gray-300">Coming Soon</h4>
            <div className="flex flex-wrap gap-2">
              {["MMA", "Golf Majors", "Esports", "College Sports"].map((item, index) => (
                <span key={index} className="bg-custom-gray-700 text-xs text-custom-gray-300 px-3 py-1 rounded-full shadow-sm">
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      <section className="bg-custom-gray-800 rounded-xl p-6 md:p-8 shadow-lg" aria-labelledby="meet-the-team-heading">
        <h3 id="meet-the-team-heading" className="text-2xl font-bold mb-6 text-center text-custom-blue-400">Meet the Team</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <TeamMember name="Alex Chen" role="Lead Data Scientist" expertise="Machine Learning & Sports Analytics" />
          <TeamMember name="Sarah Johnson" role="Head of Product" expertise="User Experience & Design" />
          <TeamMember name="Michael Rodriguez" role="Backend Architect" expertise="High-performance Systems" />
        </div>
      </section>
    </div>
  );
};

export default AboutScreen;