
import React, { useState, useEffect, useCallback, useMemo } from 'react';
// Fix: Import ApiGameScore explicitly
import { PickItem, ApiGame, Sport, ApiGameScore } from '../types';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { DAILY_FREE_PICK_LIMIT } from '../constants';

// Define types for the BallDontLie API response (NBA)
interface BallDontLieTeam { id: number; full_name: string; name: string; abbreviation: string; }
interface BallDontLieGame { id: number; date: string; home_team: BallDontLieTeam; visitor_team: BallDontLieTeam; season: number; status: string; home_team_score: number; visitor_team_score: number; time: string; }
interface BallDontLieResponse { data: BallDontLieGame[]; meta: { total_pages: number; current_page: number; next_page: number | null; per_page: number; total_count: number; };}

interface AiPredictionResult { prediction: string; probability: string; odds: string; parlayOptions: string[]; }
interface PicksScreenProps { 
  onToggleParlay: (pick: PickItem) => void; 
  selectedIds: number[]; 
  isSubscribed: boolean;
  dailyPicksUsed: number;
  lastPickUsageDate: string | null; // YYYY-MM-DD
  updateDailyPicksUsed: (count: number) => void;
}

let ai: GoogleGenAI | null = null;
let geminiApiConfigError: string | null = null;

try {
  if (typeof process !== 'undefined' && process.env && typeof process.env.API_KEY === 'string' && process.env.API_KEY.length > 0) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  } else {
    geminiApiConfigError = "API_KEY environment variable is not set or 'process' is undefined. AI features will be disabled.";
    console.warn(geminiApiConfigError);
  }
} catch (e: any) {
  geminiApiConfigError = `Error initializing GoogleGenAI: ${e.message || e.toString()}`;
  console.error(geminiApiConfigError);
}

const getTodayDateString = () => new Date().toISOString().split('T')[0];
const getFutureDateString = (days: number) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
};

const SPORTS_API_BASE_URL_NBA = 'https://www.balldontlie.io/api/v1/games';
const SUPPORTED_SPORTS: Sport[] = ['NBA', 'NFL', 'MLB', 'WNBA'];

const generateSimulatedGameId = (originalId: number, sport: Sport): number => {
  // Create more unique IDs based on sport and a random component to avoid collisions on refresh
  const randomSuffix = Math.floor(Math.random() * 10000);
  if (sport === 'NFL') return originalId + 1000000 + randomSuffix;
  if (sport === 'MLB') return originalId + 2000000 + randomSuffix;
  if (sport === 'WNBA') return originalId + 3000000 + randomSuffix;
  return originalId + randomSuffix; // For NBA, if it were simulated
};


const SportIcons: Record<Sport, React.ReactNode> = {
    NBA: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93s3.05-7.44 7-7.93v15.86zm2-15.86c1.03.13 2 .45 2.87.93H13v-.93zm0 3h1.45c.32.3.59.64.81 1H13v-1zm0 3h2.03c.05.33.07.66.07 1s-.02.67-.07 1H13v-2zm0 3h1.82c-.24.4-.55.75-.91 1.03H13v-1.03zm0 3h.87c-.87.48-1.84.8-2.87.93V17h2z"></path></svg>,
    NFL: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v2h-2v-2zm0 4h2v6h-2v-6z"></path></svg>,
    MLB: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-3.5-9.5L12 14l3.5-3.5L12 7l-3.5 3.5z"></path></svg>,
    WNBA: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M21.64 5.13c-.2-.25-.52-.39-.86-.39H3.22c-.34 0-.66.14-.86.39-.2.25-.28.59-.2.91L4.5 18.27c.15.61.68 1.02 1.31 1.02h12.38c.63 0 1.16-.41 1.31-1.02l2.34-12.23c.08-.32 0-.66-.2-.91zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z"></path></svg>,
};

const TwitterShareIcon: React.FC<{className?: string}> = ({className = "w-5 h-5"}) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733a4.67 4.67 0 002.048-2.578 9.3 9.3 0 01-2.958 1.13 4.664 4.664 0 00-7.938 4.251A13.219 13.219 0 011.778 3.72a4.662 4.662 0 001.442 6.224C2.388 9.896 1.63 9.688 1 9.338c-.002.052-.002.106-.002.16a4.66 4.66 0 003.742 4.568 4.69 4.69 0 01-2.09.08c.395.94.938 1.742 1.747 2.387a4.66 4.66 0 01-2.828 1.078A4.707 4.707 0 010 17.54a13.172 13.172 0 007.14 2.093c8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602a9.454 9.454 0 002.323-2.41z"/>
  </svg>
);


const PicksScreen: React.FC<PicksScreenProps> = ({ 
  onToggleParlay, 
  selectedIds, 
  isSubscribed,
  dailyPicksUsed,
  lastPickUsageDate,
  updateDailyPicksUsed
}) => {
  const [allPicks, setAllPicks] = useState<PickItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [gameDataErrors, setGameDataErrors] = useState<string[]>([]);
  const [refreshSignal, setRefreshSignal] = useState(0);
  const [selectedSportFilter, setSelectedSportFilter] = useState<Sport | 'All'>('All');
  const [freeUserMessage, setFreeUserMessage] = useState<string | null>(null);

  const handleRefresh = () => {
    setRefreshSignal(prev => prev + 1);
  };

  const handleShareOnTwitter = (pick: PickItem) => {
    const twitterVia = "AiLockPicksio"; // Updated to correct handle
    const appUrl = window.location.origin;
    const text = `Check out this AI-generated pick from @${twitterVia}:\n${pick.teams}: ${pick.prediction} (Odds: ${pick.odds})\n#AILockPicks #${pick.sport}Picks #SportsBetting`;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(appUrl)}&via=${twitterVia}`;
    window.open(twitterUrl, '_blank', 'noopener,noreferrer');
  };

  const mapBallDontLieGameToApiGame = (game: BallDontLieGame): ApiGame => {
    let shortStatus = "SCH"; // Scheduled
    let longStatus = game.status; // Default to API status

    if (game.status === "Final") {
        shortStatus = "FT"; // Final
    } else if (game.status === "Halftime") {
        shortStatus = "LIVE";
        longStatus = "Halftime";
    } else if (game.time && (game.status.includes("Qtr") || game.status.includes("st") || game.status.includes("nd") || game.status.includes("rd") || game.status.includes("th"))) { // e.g. "1st Qtr", "2nd Qtr" or just "Q1", "Q2"
        shortStatus = "LIVE";
        longStatus = `${game.time} - ${game.status}`;
    } else if (!isNaN(parseInt(game.status.charAt(0))) && (game.status.includes("PM") || game.status.includes("AM"))) {
        shortStatus = "SCH"; // Scheduled
    } else if (game.status.toLowerCase().includes("qtr") || game.status.toLowerCase().includes("half")) {
        shortStatus = "LIVE"; // Game in progress
    }
    return { 
        id: game.id, 
        date: game.date, 
        teams: { 
            home: { id: game.home_team.id, name: game.home_team.full_name || game.home_team.name }, 
            away: { id: game.visitor_team.id, name: game.visitor_team.full_name || game.visitor_team.name }
        }, 
        league: { id: 1, name: "NBA", season: game.season }, 
        status: { long: longStatus, short: shortStatus }, 
        scores: { home: game.home_team_score, away: game.visitor_team_score }
    };
};
  
  const fetchGamesForSport = useCallback(async (sportName: Sport): Promise<ApiGame[]> => {
    const today = new Date();
    const gameDate = (daysOffset: number) => { 
        const d = new Date(today); 
        d.setDate(today.getDate() + daysOffset); 
        d.setHours(19 + Math.floor(Math.random() * 4), Math.floor(Math.random() * 60), 0, 0); // Set game time between 7 PM - 10 PM
        return d.toISOString(); 
    };
    const currentYear = today.getFullYear();

    const generateSimulatedStatusAndScores = (gameDateStr: string): { status: { long: string; short: string; }, scores?: ApiGameScore } => {
      const gameTime = new Date(gameDateStr);
      const now = new Date();
      const timeDiffHours = (now.getTime() - gameTime.getTime()) / (1000 * 60 * 60);
      let status: { long: string; short: string; } = { short: "SCH", long: "Scheduled" };
      let scores: ApiGameScore | undefined = undefined;

      if (timeDiffHours > 0 && timeDiffHours < 3) { // Game is "live" if started in last 3 hours
          status.short = "LIVE";
          scores = { home: Math.floor(Math.random() * 60) + 40, away: Math.floor(Math.random() * 60) + 40 }; // Plausible scores
          if (sportName === "NFL") {
              const quarter = Math.min(4, Math.floor(timeDiffHours / 0.75) + 1);
              const timeInQuarter = Math.floor(Math.random() * 15);
              status.long = `Q${quarter} - ${String(15 - timeInQuarter).padStart(2, '0')}:${String(Math.floor(Math.random()*60)).padStart(2, '0')}`;
          } else if (sportName === "MLB") {
              const inning = Math.min(9, Math.floor(timeDiffHours / 0.33) + 1);
              status.long = `${inning}${inning === 1 ? 'st' : inning === 2 ? 'nd' : inning === 3 ? 'rd' : 'th'} Inning`;
              scores = { home: Math.floor(Math.random() * 6), away: Math.floor(Math.random() * 6) };
          } else if (sportName === "WNBA" || sportName === "NBA") { // Similar logic for basketball
              const quarter = Math.min(4, Math.floor(timeDiffHours / 0.75) + 1);
              const timeInQuarter = Math.floor(Math.random() * 12);
              status.long = `Q${quarter} - ${String(12 - timeInQuarter).padStart(2, '0')}:${String(Math.floor(Math.random()*60)).padStart(2, '0')}`;
          } else {
              status.long = "In Progress";
          }
      } else if (timeDiffHours >= 3) { // Game finished
          status.short = "FT";
          status.long = "Final";
          if (sportName === "NFL") scores = { home: Math.floor(Math.random() * 30) + 10, away: Math.floor(Math.random() * 30) + 10 };
          else if (sportName === "MLB") scores = { home: Math.floor(Math.random() * 7), away: Math.floor(Math.random() * 7) };
          else scores = { home: Math.floor(Math.random() * 60) + 80, away: Math.floor(Math.random() * 60) + 80 };
      }
      return { status, scores };
    };


    if (sportName === 'NBA') {
        const startDate = getTodayDateString();
        const endDate = getFutureDateString(7);
        const fullApiUrl = `${SPORTS_API_BASE_URL_NBA}?start_date=${startDate}&end_date=${endDate}&per_page=5`; // Fetch more to get diverse statuses
        const response = await fetch(fullApiUrl);
        if (!response.ok) throw new Error(`Failed to fetch NBA game data: ${response.statusText}.`);
        const gamesResponse: BallDontLieResponse = await response.json();
        return gamesResponse.data.map(mapBallDontLieGameToApiGame).filter(game => game.status?.short !== "POST"); // Filter out Postponed
    } else {
        let games: Omit<ApiGame, 'status' | 'scores' | 'league'>[] = [];
        let leagueId: number;
        
        if (sportName === 'NFL') {
            leagueId = 2;
            games = [
                { id: generateSimulatedGameId(1, 'NFL'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 101, name: "Kansas City Chiefs" }, away: { id: 102, name: "Buffalo Bills" } } },
                { id: generateSimulatedGameId(2, 'NFL'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 103, name: "Philadelphia Eagles" }, away: { id: 104, name: "Dallas Cowboys" } } },
                { id: generateSimulatedGameId(3, 'NFL'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 105, name: "San Francisco 49ers" }, away: { id: 106, name: "Cincinnati Bengals" } } },
            ];
        } else if (sportName === 'MLB') {
            leagueId = 3;
            games = [
                { id: generateSimulatedGameId(1, 'MLB'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 201, name: "New York Yankees" }, away: { id: 202, name: "Boston Red Sox" } } },
                { id: generateSimulatedGameId(2, 'MLB'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 203, name: "Los Angeles Dodgers" }, away: { id: 204, name: "San Francisco Giants" } } },
                { id: generateSimulatedGameId(3, 'MLB'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 205, name: "Houston Astros" }, away: { id: 206, name: "Atlanta Braves" } } },
            ];
        } else if (sportName === 'WNBA') {
            leagueId = 4;
            games = [
                { id: generateSimulatedGameId(1, 'WNBA'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 301, name: "Las Vegas Aces" }, away: { id: 302, name: "New York Liberty" } } },
                { id: generateSimulatedGameId(2, 'WNBA'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 303, name: "Seattle Storm" }, away: { id: 304, name: "Phoenix Mercury" } } },
                { id: generateSimulatedGameId(3, 'WNBA'), date: gameDate(Math.floor(Math.random() * 7)), teams: { home: { id: 305, name: "Connecticut Sun" }, away: { id: 306, name: "Chicago Sky" } } },
            ];
        } else { return []; }
        
        return games.map(game => {
            const gameYear = new Date(game.date).getFullYear(); // Get year from the generated game date
            const { status, scores } = generateSimulatedStatusAndScores(game.date);
            return {
                ...game,
                league: { id: leagueId, name: sportName, season: gameYear }, // Use dynamic gameYear for season
                status: status,
                scores: scores
            };
        });
    }
  }, []);

  const getAiPredictionForGame = useCallback(async (game: ApiGame): Promise<Partial<PickItem>> => {
    if (!ai) return { prediction: "AI is not configured", probability: "-", odds: "-", parlayOptions: ["N/A"], gameDate: game.date };
    
    const homeTeamName = game.teams.home.name.substring(0, 40);
    const awayTeamName = game.teams.away.name.substring(0, 40);
    let sportSpecificParlayExamples = `["${homeTeamName} ML", "Spread ${homeTeamName} -X.X", "Total Over/Under Y.Y Points"]`;
    if (game.league.name === "NFL") sportSpecificParlayExamples = `["${homeTeamName} ML", "${awayTeamName} +X.X Spread", "Anytime Touchdown Scorer Name", "Total Points Over Z.Z"]`;
    if (game.league.name === "MLB") sportSpecificParlayExamples = `["${homeTeamName} ML", "Run Line ${awayTeamName} +1.5", "Total Runs Under A.A", "First 5 Innings Winner"]`;
    if (game.league.name === "WNBA") sportSpecificParlayExamples = `["${homeTeamName} ML", "${awayTeamName} to cover +X.X spread", "Player Points Over Y.Y (Star Player)", "Game Total Over Z.Z"]`;

    const currentDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    const prompt = `
      Given that today is ${currentDate}, analyze the upcoming ${game.league.name} game: ${homeTeamName} (home) vs ${awayTeamName} (away) scheduled for ${new Date(game.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: '2-digit' })}.
      This game is part of the ${game.league.name}${game.league.season ? ` ${game.league.season} season` : ''}.

      Provide a JSON object with:
      1. "prediction": A single, specific betting prediction (e.g., "${homeTeamName} to win by +X.X points", "Total score Over Y.Y points", or "${awayTeamName} Moneyline"). This is the main pick. If a reliable prediction is not possible due to the game date being unusual for the sport's typical season (e.g., off-season), too far in the future, or due to lack of sufficient current data, state that clearly in this field (e.g., "Cannot predict: Game is out of typical season" or "Prediction unavailable: Game too far in future").
      2. "probability": Estimated probability for THIS specific prediction (e.g., "65%"). If prediction is not possible, set to "N/A".
      3. "odds": Suggested American odds for THIS prediction (e.g., "+150" or "-120"). If prediction is not possible, set to "N/A".
      4. "parlayOptions": An array of 3-4 DIVERSE and RELEVANT parlay option strings for this specific ${game.league.name} game. These are additional betting angles. Example format: ${sportSpecificParlayExamples}. If prediction is not possible, set to ["Unavailable"].
      
      Example JSON response format if prediction IS possible:
      {
        "prediction": "${homeTeamName} Moneyline",
        "probability": "62%",
        "odds": "-150",
        "parlayOptions": ${sportSpecificParlayExamples}
      }

      Example JSON response format if prediction IS NOT possible:
      {
        "prediction": "Cannot predict: Game date is outside typical NFL season.",
        "probability": "N/A",
        "odds": "N/A",
        "parlayOptions": ["Unavailable"]
      }
    `;

    try {
      const result: GenerateContentResponse = await ai.models.generateContent({ model: 'gemini-2.5-flash-preview-04-17', contents: prompt, config: { responseMimeType: "application/json" }});
      let jsonStr = result.text.trim();
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
      const match = jsonStr.match(fenceRegex);
      if (match && match[2]) jsonStr = match[2].trim();
      const aiData: AiPredictionResult = JSON.parse(jsonStr);

      if (aiData && typeof aiData.prediction === 'string' && typeof aiData.probability === 'string' && typeof aiData.odds === 'string' && Array.isArray(aiData.parlayOptions) && aiData.parlayOptions.every(opt => typeof opt === 'string')) {
        return { ...aiData, gameDate: game.date };
      }
      // If AI returns a valid JSON but not our expected structure, treat as prediction unavailable
      return { prediction: "AI returned unexpected data structure.", probability: "N/A", odds: "N/A", parlayOptions: ["Unavailable"], gameDate: game.date };
    } catch (e) {
      console.error(`Failed AI prediction for game ${game.id} (${game.league.name}):`, e);
      let reason = "AI prediction error or timeout.";
      const gameTime = new Date(game.date);
      const now = new Date();
      const diffDays = (gameTime.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) { reason = "Game too far in future for reliable AI prediction."; }
      else if (diffDays < -2) { reason = "Game already played or too far in past."; }
      
      return { prediction: reason, probability: "N/A", odds: "N/A", parlayOptions: ["Unavailable"], gameDate: game.date };
    }
  }, []);

  useEffect(() => {
    const fetchAllPicks = async () => {
      setLoading(true); setError(null); setGameDataErrors([]); setFreeUserMessage(null);
      let allUpcomingApiGames: ApiGame[] = [];
      const currentErrors: string[] = [];

      for (const sport of SUPPORTED_SPORTS) {
        try {
            const games = await fetchGamesForSport(sport);
            allUpcomingApiGames.push(...games);
        } catch (err: any) {
            currentErrors.push(`Failed to load ${sport} games: ${err.message || 'Unknown error'}.`);
        }
      }
      setGameDataErrors(currentErrors);
      
      allUpcomingApiGames.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      let gamesToProcessWithAi: ApiGame[] = [];
      
      if (isSubscribed) {
        gamesToProcessWithAi = allUpcomingApiGames;
        setFreeUserMessage(null);
      } else {
        const todayStr = new Date().toISOString().split('T')[0];
        let currentDayPicksUsed = dailyPicksUsed;
        if (lastPickUsageDate !== todayStr) { 
            currentDayPicksUsed = 0;
        }

        const remainingFreePicksToday = DAILY_FREE_PICK_LIMIT - currentDayPicksUsed;

        if (remainingFreePicksToday <= 0) {
          gamesToProcessWithAi = [];
          setFreeUserMessage(`You've used all ${DAILY_FREE_PICK_LIMIT} free AI picks for today. Subscribe for unlimited access or check back tomorrow!`);
        } else {
          gamesToProcessWithAi = allUpcomingApiGames.slice(0, remainingFreePicksToday);
          if (gamesToProcessWithAi.length > 0) {
             updateDailyPicksUsed(currentDayPicksUsed + gamesToProcessWithAi.length);
          }
          const newRemaining = DAILY_FREE_PICK_LIMIT - (currentDayPicksUsed + gamesToProcessWithAi.length);
          if (gamesToProcessWithAi.length > 0) {
            setFreeUserMessage(`Displaying ${gamesToProcessWithAi.length} AI pick(s). You have ${newRemaining} free pick(s) remaining today.`);
          } else if (allUpcomingApiGames.length === 0 && remainingFreePicksToday > 0){
            setFreeUserMessage("No new games available for your free picks right now. Check back later!");
          } else if (allUpcomingApiGames.length > 0 && remainingFreePicksToday > 0 && gamesToProcessWithAi.length === 0) {
             setFreeUserMessage(`No new games match your remaining ${remainingFreePicksToday} free pick slots. Check back later or try refreshing.`);
          } else {
             setFreeUserMessage(`You have ${newRemaining} free pick(s) remaining today.`);
          }
        }
      }

      if (gamesToProcessWithAi.length === 0 && !isSubscribed) {
        setAllPicks([]);
        setLoading(false);
        if (allUpcomingApiGames.length === 0 && gameDataErrors.length === SUPPORTED_SPORTS.length) {
           setError("Failed to load game data from all sources.");
        }
        return;
      }
      
      if (geminiApiConfigError && !ai) {
        const gamesWithoutAi = gamesToProcessWithAi.map(game => ({
            id: game.id,
            sport: game.league.name,
            teams: `${game.teams.home.name} vs ${game.teams.away.name}`,
            prediction: "AI is not configured",
            probability: "-",
            odds: "-",
            parlayOptions: ["N/A"],
            gameDate: game.date,
            sportIcon: SportIcons[game.league.name],
            status: game.status, 
            scores: game.scores,
        } as PickItem)); 
        setAllPicks(gamesWithoutAi); setError(geminiApiConfigError); setLoading(false); return;
      }

      try {
        const enhancedPicksPromises = gamesToProcessWithAi.map(async (game: ApiGame) => {
          const aiPredictionData = await getAiPredictionForGame(game);
          const pickEntry = {
            id: game.id,
            sport: game.league.name,
            teams: `${game.teams.home.name} vs ${game.teams.away.name}`,
            prediction: aiPredictionData.prediction || "Prediction unavailable",
            probability: aiPredictionData.probability || "-",
            odds: aiPredictionData.odds || "-",
            parlayOptions: aiPredictionData.parlayOptions || ["N/A"],
            gameDate: aiPredictionData.gameDate || game.date,
            sportIcon: SportIcons[game.league.name],
            status: game.status, 
            scores: game.scores, 
          };
          return pickEntry as PickItem; 
        });
        const resolvedPicks = await Promise.all(enhancedPicksPromises);
        setAllPicks(resolvedPicks);
      } catch (err: any) {
        setError(err.message || 'Error fetching AI predictions.');
        const gamesWithAiError = gamesToProcessWithAi.map(game => ({
            id: game.id,
            sport: game.league.name,
            teams: `${game.teams.home.name} vs ${game.teams.away.name}`,
            prediction: "AI prediction error",
            probability: "-",
            odds: "-",
            parlayOptions: ["N/A"],
            gameDate: game.date,
            sportIcon: SportIcons[game.league.name],
            status: game.status,
            scores: game.scores,
        } as PickItem));
        setAllPicks(gamesWithAiError);
      } finally { setLoading(false); }
    };
    fetchAllPicks();
  }, [getAiPredictionForGame, fetchGamesForSport, refreshSignal, isSubscribed, dailyPicksUsed, lastPickUsageDate, updateDailyPicksUsed]);

  const filteredPicks = useMemo(() => {
    if (selectedSportFilter === 'All') return allPicks;
    return allPicks.filter(pick => pick.sport === selectedSportFilter);
  }, [allPicks, selectedSportFilter]);

  const formatGameDate = (isoDate: string, status?: {long?: string; short?: string}) => {
    if (status?.short === 'LIVE' && status.long) return status.long;
    const date = new Date(isoDate);
    return `${date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} - ${date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', hour12: true })}`;
  };

  if (loading) return (
    <div role="status" aria-live="polite" className="text-center py-12">
      <div className="inline-flex items-center text-xl text-custom-gray-300">
        <svg className="animate-spin -ml-1 mr-3 h-8 w-8 text-custom-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
        Gathering Intelligence & Crafting Picks... Please Wait.
      </div>
    </div>
  );
  
  const combinedErrorMessages = [...gameDataErrors, error && !geminiApiConfigError ? `AI Error: ${error}` : null].filter(Boolean).join('; ');

  return (
    <div aria-labelledby="picks-screen-heading">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h2 id="picks-screen-heading" className="text-3xl font-bold text-white">Today's AI Lock Picks</h2>
        <div className="flex items-center gap-3">
          <div className="relative">
            <select
              id="sportFilter"
              value={selectedSportFilter}
              onChange={(e) => setSelectedSportFilter(e.target.value as Sport | 'All')}
              className="bg-custom-gray-700 border border-custom-gray-600 text-white text-sm rounded-lg focus:ring-custom-blue-500 focus:border-custom-blue-500 block w-full p-2.5 appearance-none pr-8"
              aria-label="Filter picks by sport"
            >
              <option value="All">All Sports</option>
              {SUPPORTED_SPORTS.map(sport => <option key={sport} value={sport}>{sport}</option>)}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-custom-gray-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </div>
          </div>
          <button onClick={handleRefresh} disabled={loading} className="flex items-center bg-custom-blue-600 hover:bg-custom-blue-700 text-white font-medium py-2.5 px-4 rounded-lg shadow-md hover:shadow-lg transition-all transform hover:scale-105 disabled:opacity-60 disabled:cursor-not-allowed" aria-label="Refresh AI picks">
            <svg className={`w-5 h-5 mr-2 ${loading ? 'animate-spin' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" ><path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" /></svg>
            {loading ? 'Refreshing...' : 'Refresh Picks'}
          </button>
        </div>
      </div>

       {freeUserMessage && !isSubscribed && (
        <div role="alert" className="mb-6 text-center py-4 text-lg text-custom-yellow-400 bg-gradient-to-r from-yellow-700/30 to-custom-purple-700/30 border border-custom-yellow-600 p-4 rounded-lg shadow-md">
          {freeUserMessage}
          {!freeUserMessage.toLowerCase().includes("subscribe") && (
            <button onClick={() => (document.querySelector('button[aria-label="Home Tab"]')?.dispatchEvent(new MouseEvent('click', {bubbles: true})))} 
                    className="ml-2 underline hover:text-yellow-300 font-semibold focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded">
              Subscribe to Premium
            </button>
          )}
           for unlimited access!
        </div>
      )}

      {geminiApiConfigError && (
         <div role="alert" className="mb-6 text-center py-4 text-lg text-yellow-300 bg-yellow-700/30 border border-yellow-600 p-4 rounded-lg shadow-md">AI Features Disabled: {geminiApiConfigError} Game data might be shown, but AI predictions are unavailable.</div>
      )}
       {combinedErrorMessages && !loading && (!filteredPicks || filteredPicks.length === 0) && !geminiApiConfigError && ( 
         <div role="alert" className="mb-6 text-center py-4 text-lg text-custom-red-400 bg-red-700/20 border border-red-600 p-6 rounded-lg shadow-md">Error: {combinedErrorMessages}</div>
      )}
      {error && !geminiApiConfigError && filteredPicks && filteredPicks.length > 0 && filteredPicks.some(p => p.prediction === "AI prediction unavailable" || p.prediction === "AI prediction error") && gameDataErrors.length === 0 && (
         <div role="alert" className="mb-6 text-center py-3 text-yellow-400 bg-yellow-700/30 border border-yellow-600 p-4 rounded-lg shadow-md">Notice: {error || "Some AI predictions might be unavailable."} Game data is shown.</div>
      )}
      {gameDataErrors.length > 0 && filteredPicks && filteredPicks.length > 0 && ( 
         <div role="alert" className="mb-6 text-center py-3 text-sm text-yellow-400 bg-yellow-700/30 border border-yellow-600 p-4 rounded-lg shadow-md">Game Data Issues: {gameDataErrors.join('; ')}. Displaying available picks.</div>
      )}

      {filteredPicks.length === 0 && !loading && !combinedErrorMessages && !geminiApiConfigError && !freeUserMessage?.includes("used all") && ( 
        <div className="text-center py-12 text-xl text-custom-gray-400 bg-custom-gray-800 p-8 rounded-lg shadow-xl">
          <svg className="w-16 h-16 mx-auto text-custom-gray-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          No upcoming games found for "{selectedSportFilter}" or AI picks available matching your current criteria. Try a different filter or refresh.
        </div>
      )}

      {filteredPicks.length > 0 && (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredPicks.map((pick) => {
            const pickWithGameData = pick as PickItem & { status?: ApiGame['status'], scores?: ApiGameScore };
            const isLive = pickWithGameData.status?.short === 'LIVE' && pickWithGameData.scores;

            const isPickDisabledByPrediction = pick.prediction.startsWith("AI") || pick.odds === "-" || pick.prediction.toLowerCase().includes("cannot predict") || pick.prediction.toLowerCase().includes("unavailable");
            const canAddToParlay = !isPickDisabledByPrediction; 

            return (
            <div key={pick.id} className={`bg-custom-gray-800 rounded-xl overflow-hidden shadow-xl hover:shadow-custom-blue-500/40 transition-all duration-300 ease-in-out hover:ring-2 hover:ring-custom-blue-600 transform hover:-translate-y-1 flex flex-col`}>
              <div className="p-5 flex-grow">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-2">
                     <span className="text-custom-blue-400" aria-label={pick.sport}>{pick.sportIcon || SportIcons[pick.sport]}</span>
                     <span className="bg-custom-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider">{pick.sport}</span>
                  </div>
                  {!isLive && (
                    <span className="text-xs text-custom-gray-400">{formatGameDate(pickWithGameData.gameDate, pickWithGameData.status)}</span>
                  )}
                </div>
                
                <h3 className="text-lg font-bold mb-1 text-white">{pick.teams}</h3>

                {isLive && pickWithGameData.scores && (
                  <div className="mb-3 text-center">
                    <div className="text-2xl font-bold text-custom-yellow-400">
                      {(() => {
                        const teamNames = pickWithGameData.teams.split(' vs ');
                        const homeTeamDisplayName = teamNames[0] ? teamNames[0].trim().split(' ').pop() : 'Home';
                        const awayTeamDisplayName = teamNames[1] ? teamNames[1].trim().split(' ').pop() : 'Away';
                        const homeScore = pickWithGameData.scores?.home ?? '-';
                        const awayScore = pickWithGameData.scores?.away ?? '-';
                        return `${homeTeamDisplayName} ${homeScore} - ${awayScore} ${awayTeamDisplayName}`;
                      })()}
                    </div>
                    <div className="text-sm text-custom-green-400">{pickWithGameData.status?.long || "Live"}</div>
                  </div>
                )}
                
                <p className={`font-semibold mb-3 text-md ${isPickDisabledByPrediction ? 'text-yellow-500' : 'text-custom-blue-300'}`}>{pick.prediction}</p>
                
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-custom-gray-700 p-3 rounded-lg text-center">
                    <div className="text-xs text-custom-gray-400 uppercase tracking-wider">Probability</div>
                    <div className={`text-md font-bold ${(pick.probability === "-" || pick.probability === "N/A") ? 'text-custom-gray-400' : 'text-custom-green-400'}`}>{pick.probability}</div>
                  </div>
                  <div className="bg-custom-gray-700 p-3 rounded-lg text-center">
                    <div className="text-xs text-custom-gray-400 uppercase tracking-wider">Odds</div>
                    <div className={`text-md font-bold ${(pick.odds === "-" || pick.odds === "N/A") ? 'text-custom-gray-400' : 'text-yellow-400'}`}>{pick.odds}</div>
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-custom-gray-300 mb-1.5 font-medium">Consider for Parlay:</div>
                  <div className="flex flex-wrap gap-1.5" aria-label="Parlay options">
                    {pick.parlayOptions.slice(0, 4).map((option, index_opt) => ( 
                      <span key={index_opt} className={`text-xs px-2 py-0.5 rounded-full ${(option === "N/A" || option === "Unavailable") ? 'bg-custom-gray-600 text-custom-gray-400' : 'bg-custom-gray-700/80 text-custom-gray-300 hover:bg-custom-gray-600'}`}>
                        {option}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="p-4 bg-custom-gray-700/30 border-t border-custom-gray-700">
                 <div className="flex justify-between items-center">
                    <button 
                        onClick={() => onToggleParlay(pick)}
                        aria-pressed={selectedIds.includes(pick.id)}
                        aria-label={selectedIds.includes(pick.id) ? `Remove ${pick.teams} (${pick.sport}) from parlay` : `Add ${pick.teams} (${pick.sport}) to parlay`}
                        className={`w-auto flex-grow px-3 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 ease-in-out transform focus:outline-none focus:ring-2 focus:ring-opacity-50
                        ${ selectedIds.includes(pick.id)
                            ? 'bg-custom-green-500 hover:bg-custom-green-600 text-white shadow-md focus:ring-custom-green-400'
                            : 'bg-custom-blue-500 hover:bg-custom-blue-600 text-white shadow-md hover:shadow-lg focus:ring-custom-blue-400'
                        }
                        ${!canAddToParlay ? 'opacity-60 cursor-not-allowed' : ''}
                        `}
                        disabled={!canAddToParlay}
                    >
                        {selectedIds.includes(pick.id) ? 'Added to Parlay ✓' : 'Add to Parlay +'}
                    </button>
                    <button
                        onClick={() => handleShareOnTwitter(pick)}
                        aria-label={`Share pick for ${pick.teams} on Twitter`}
                        className="ml-3 p-2.5 bg-custom-gray-600 hover:bg-custom-blue-500 text-white rounded-lg transition-colors duration-200 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-custom-blue-400"
                    >
                        <TwitterShareIcon className="w-4 h-4" />
                    </button>
                 </div>
              </div>
            </div>
          )})}
        </div>
      )}
    </div>
  );
};

export default PicksScreen;
