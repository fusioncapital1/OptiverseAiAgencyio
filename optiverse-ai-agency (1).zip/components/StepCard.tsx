
import React from 'react';
import { StepCardProps } from '../types';

const StepCard: React.FC<StepCardProps> = ({ number, title, description }) => {
  return (
    <div className="text-center">
      <div className="bg-custom-blue-600 text-white rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-3 font-bold text-lg" aria-hidden="true">
        {number}
      </div>
      <h4 className="font-semibold mb-2 text-white">{title}</h4>
      <p className="text-custom-gray-400 text-sm">{description}</p>
    </div>
  );
};

export default StepCard;