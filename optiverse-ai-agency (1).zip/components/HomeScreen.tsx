

import React from 'react';
import FeatureCard from './FeatureCard';
import StepCard from './StepCard';
import { ActiveTab } from '../types';
import { handleSubscriptionCheckout } from '../stripeService'; // Import Stripe handler
// Fix: Import DAILY_FREE_PICK_LIMIT
import { DAILY_FREE_PICK_LIMIT } from '../constants';

interface HomeScreenProps {
  setActiveTab: (tab: ActiveTab) => void;
  setIsSubscribed: (status: boolean) => void; // To update subscription status
  isSubscribed: boolean; // To show current status
}

const HomeScreen: React.FC<HomeScreenProps> = ({ setActiveTab, setIsSubscribed, isSubscribed }) => {
  
  const onSubscribeClick = async () => {
    const result = await handleSubscriptionCheckout();
    if (result?.error) {
      console.error("Stripe Checkout failed:", result.error);
      // Error is usually alerted by stripeService, but handle further if needed
    }
    // Success is handled by redirect and useEffect in App.tsx
  };

  return (
    <div className="space-y-12">
      <section className="text-center py-12" aria-labelledby="hero-heading">
        <h2 id="hero-heading" className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-custom-blue-400 to-custom-purple-500 bg-clip-text text-transparent">
          Unlock Winning Picks with AI
        </h2>
        <p className="text-xl md:text-2xl text-custom-gray-300 max-w-3xl mx-auto">
          Our advanced algorithms analyze all relevant sports data to give you the highest probability betting options.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
          <button 
            onClick={() => setActiveTab('picks')}
            className="bg-custom-blue-600 hover:bg-custom-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform transition hover:scale-105"
          >
            View Today's Picks
          </button>
          <button 
            onClick={() => setActiveTab('about')}
            className="bg-custom-gray-700 hover:bg-custom-gray-600 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform transition hover:scale-105"
          >
            Learn How It Works
          </button>
        </div>
      </section>

      {!isSubscribed && (
        <section className="bg-custom-gray-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-custom-blue-500/50" aria-labelledby="premium-heading">
          <div className="text-center">
            <h3 id="premium-heading" className="text-3xl font-bold mb-3 text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-stripe-pink">
              Go Premium!
            </h3>
            <p className="text-lg text-custom-gray-300 mb-2 max-w-xl mx-auto">
              Get unlimited AI picks, advanced parlay insights, and priority updates for just <span className="font-bold text-white">$7.99/month</span>.
            </p>
            <p className="text-sm text-custom-gray-400 mb-6 max-w-xl mx-auto">
              Free users get {DAILY_FREE_PICK_LIMIT} AI picks per day.
            </p>
            <button 
              onClick={onSubscribeClick}
              className="bg-gradient-to-r from-custom-blue-500 to-custom-purple-500 hover:from-custom-blue-600 hover:to-custom-purple-600 text-white font-bold py-4 px-10 rounded-lg shadow-xl transform transition hover:scale-105 text-lg focus:outline-none focus:ring-4 focus:ring-custom-purple-500/50"
            >
              Subscribe for $7.99/month
            </button>
             <p className="text-xs text-custom-gray-500 mt-3">Secure payment processing by Stripe.</p>
          </div>
        </section>
      )}
       {isSubscribed && (
        <section className="bg-custom-green-800/20 border border-custom-green-500 p-6 rounded-xl shadow-lg text-center" aria-labelledby="subscribed-info">
            <h3 id="subscribed-info" className="text-2xl font-bold text-custom-green-400 mb-2">You are Subscribed!</h3>
            <p className="text-custom-gray-300">Thank you for supporting AI Lock Picks. All premium features, including unlimited AI picks, are unlocked.</p>
        </section>
      )}


      <section aria-labelledby="features-heading">
        <h3 id="features-heading" className="sr-only">Features</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <FeatureCard 
            title="AI-Powered Analysis"
            description="Our system analyzes thousands of data points including player performance, weather conditions, team dynamics, and historical patterns."
            icon={
              <svg className="w-10 h-10 text-custom-blue-400" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9.6 21H4.8C4.04087 21 3.31289 20.7003 2.7612 20.1777C2.20952 19.6551 2 18.9667 2 18.24V5.76C2 5.03329 2.20952 4.34489 2.7612 3.82233C3.31289 3.29976 4.04087 3 4.8 3H19.2C19.9591 3 20.6871 3.29976 21.2388 3.82233C21.7905 4.34489 22 5.03329 22 5.76V11.4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M18 16L14 12L10 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 12V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="7.5" cy="13.5" r="1.5" fill="currentColor"/>
                <circle cx="16.5" cy="13.5" r="1.5" fill="currentColor"/>
              </svg>
            }
          />
          <FeatureCard 
            title="Smart Parlay Builder"
            description="Combine multiple high-probability bets into one powerful parlay with calculated risk/reward analysis and real-time probability updates."
            icon={
              <svg className="w-10 h-10 text-custom-blue-400" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 12H16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12 16V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            }
          />
          <FeatureCard 
            title="Real-Time Updates"
            description="Stay ahead with live updates as our models adapt to breaking news, injuries, and line movements across all major sports leagues."
            icon={
              <svg className="w-10 h-10 text-custom-blue-400" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 8V12L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            }
          />
        </div>
      </section>

      <section className="bg-custom-gray-800 p-6 sm:p-8 rounded-xl shadow-lg" aria-labelledby="how-it-works-heading">
        <h3 id="how-it-works-heading" className="text-2xl font-bold mb-6 text-center text-white">How It Works</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <StepCard number="1" title="Data Collection" description="We gather real-time stats, player performance metrics, weather reports, and historical game data." />
          <StepCard number="2" title="AI Analysis" description="Our neural networks process the data to identify patterns and predict outcomes with statistical confidence." />
          <StepCard number="3" title="Probability Calculation" description="Each potential bet is assigned a probability percentage based on the AI's confidence level." />
          <StepCard number="4" title="Optimal Betting" description="Receive curated picks and build smart parlays with calculated risk/reward ratios." />
        </div>
      </section>
    </div>
  );
};

export default HomeScreen;