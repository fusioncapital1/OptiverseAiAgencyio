import React from 'react';
import { ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
  parlaySelectionsCount: number;
}

const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, isMenuOpen, setIsMenuOpen, parlaySelectionsCount }) => {
  const navItems: { id: ActiveTab; label: string; showCount?: boolean, ariaLabel?: string }[] = [
    { id: 'home', label: 'Home', ariaLabel: 'Home Tab' },
    { id: 'picks', label: 'AI Picks', ariaLabel: 'AI Picks Tab' },
    { id: 'parlay', label: 'Parlay Builder', showCount: true, ariaLabel: 'Parlay Builder Tab' },
    { id: 'about', label: 'About', ariaLabel: 'About Tab' },
  ];

  return (
    <header className="bg-custom-gray-800 shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <svg className="w-8 h-8 text-custom-blue-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <h1 className="text-xl font-bold">AI Lock Picks</h1>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-6">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`hover:text-custom-blue-400 transition ${activeTab === item.id ? 'text-custom-blue-400' : ''}`}
              aria-current={activeTab === item.id ? 'page' : undefined}
              aria-label={item.ariaLabel || item.label}
            >
              {item.label}
              {item.showCount && parlaySelectionsCount > 0 && (
                <span className="ml-1 inline-block bg-custom-blue-500 rounded-full w-5 h-5 text-xs flex items-center justify-center" aria-label={`${parlaySelectionsCount} items in parlay`}>
                  {parlaySelectionsCount}
                </span>
              )}
            </button>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-expanded={isMenuOpen} aria-controls="mobile-menu">
          <span className="sr-only">Open main menu</span>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            {isMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div id="mobile-menu" className="md:hidden bg-custom-gray-700 p-4">
          <nav className="flex flex-col space-y-3">
            {navItems.map((item) => (
               <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMenuOpen(false);
                }}
                className={`py-2 px-3 text-left hover:bg-custom-gray-600 rounded flex justify-between items-center ${activeTab === item.id ? 'bg-custom-blue-600 text-white' : 'text-custom-gray-300'}`}
                aria-current={activeTab === item.id ? 'page' : undefined}
                aria-label={item.ariaLabel || item.label}
              >
                <span>{item.label}</span>
                {item.showCount && parlaySelectionsCount > 0 && (
                  <span className="inline-block bg-custom-blue-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center" aria-label={`${parlaySelectionsCount} items in parlay`}>
                    {parlaySelectionsCount}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;