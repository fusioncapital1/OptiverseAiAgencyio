
import React from 'react';

const TwitterIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733a4.67 4.67 0 002.048-2.578 9.3 9.3 0 01-2.958 1.13 4.664 4.664 0 00-7.938 4.251A13.219 13.219 0 011.778 3.72a4.662 4.662 0 001.442 6.224C2.388 9.896 1.63 9.688 1 9.338c-.002.052-.002.106-.002.16a4.66 4.66 0 003.742 4.568 4.69 4.69 0 01-2.09.08c.395.94.938 1.742 1.747 2.387a4.66 4.66 0 01-2.828 1.078A4.707 4.707 0 010 17.54a13.172 13.172 0 007.14 2.093c8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602a9.454 9.454 0 002.323-2.41z"/>
  </svg>
);

const FacebookIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/>
  </svg>
);

const InstagramIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.359 2.618 6.78 6.98 6.98 1.281.059 1.689.073 4.948.073s3.667-.014 4.947-.072c4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.947s-.014-3.667-.072-4.947c-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.689-.073-4.948-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4c2.21 0 4 1.791 4 4s-1.79 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
  </svg>
);

const YouTubeIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
  </svg>
);

const LinkedInIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065s.919-2.065 2.063-2.065 2.064.926 2.064 2.065-.92 2.065-2.064 2.065zm1.776 13.019H3.561V9h3.552v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.225 0z"/>
  </svg>
);

interface SocialProfile {
  url: string;
  icon: React.ReactNode;
  label: string;
  handle?: string; // Make handle optional
  platformName?: string; // e.g., "X (Twitter)", "Instagram"
}

const SocialLink: React.FC<{ href: string; label: string; icon: React.ReactNode; }> = ({ href, label, icon }) => (
  <a 
    href={href} 
    target="_blank" 
    rel="noopener noreferrer"
    aria-label={label}
    className="text-custom-gray-400 hover:text-custom-blue-400 transition-colors duration-200"
  >
    {icon}
  </a>
);

const Footer: React.FC = () => {
  const socialProfiles: Record<string, SocialProfile> = {
    aiLockPicksTwitter: { 
      url: "https://twitter.com/AiLockPicksio", 
      icon: <TwitterIcon />, 
      label: "Follow AI Lock Picks on X (Twitter)",
      handle: "AiLockPicksio",
      platformName: "X (Twitter)"
    },
    aiLockPicksInstagram: { 
      url: "https://instagram.com/ailockpicksio", 
      icon: <InstagramIcon />, 
      label: "Follow AI Lock Picks on Instagram",
      handle: "ailockpicksio",
      platformName: "Instagram"
    },
    aiLockPicksYouTube: { 
      url: "https://www.youtube.com/@AiLockPicksio1.0",
      icon: <YouTubeIcon />, 
      label: "Subscribe to AI Lock Picks on YouTube",
      handle: "@AiLockPicksio1.0",
      platformName: "YouTube"
    },
    aiLockPicksFacebook: { 
      url: "YOUR_AILOCKPICKS_FACEBOOK_URL", // Placeholder - Replace with actual URL
      icon: <FacebookIcon />, 
      label: "Follow AI Lock Picks on Facebook",
      platformName: "Facebook (Coming Soon)"
    },
    optiverseLinkedIn: { 
      url: "YOUR_OPTIVERSE_LINKEDIN_URL", // Placeholder - Replace with actual URL
      icon: <LinkedInIcon />, 
      label: "Connect with Optiverse Ai Agency on LinkedIn",
      platformName: "LinkedIn (Optiverse Ai Agency - Coming Soon)" 
    },
  };

  const activeProfiles = Object.values(socialProfiles).filter(
    profile => profile.url && !profile.url.startsWith("YOUR_") && profile.url !== "#"
  );

  const pendingProfiles = Object.values(socialProfiles).filter(
    profile => profile.url && (profile.url.startsWith("YOUR_") || profile.url === "#")
  );


  return (
    <footer className="bg-custom-gray-800 mt-12 py-8">
      <div className="container mx-auto px-4 text-center text-custom-gray-400">
        {activeProfiles.length > 0 && (
          <div className="flex justify-center items-center space-x-6 mb-4">
            {activeProfiles.map((profile, index) => (
              <SocialLink key={index} href={profile.url} label={profile.label} icon={profile.icon} />
            ))}
          </div>
        )}
        
        <div className="mt-2 text-xs space-y-1">
          {activeProfiles.map((profile, index) => (
            profile.handle && profile.platformName && (
              <p key={`handle-${index}`}>Follow us on {profile.platformName}: {profile.handle.startsWith("@") ? profile.handle : "@" + profile.handle}</p>
            )
          ))}
          {pendingProfiles.map((profile, index) => (
             profile.platformName && (
              <p key={`pending-${index}`} className="text-custom-gray-500 italic">{profile.platformName}</p>
             )
          ))}
        </div>

        <p className="mt-4">&copy; {new Date().getFullYear()} AI Lock Picks. All rights reserved.</p>
        <p className="mt-2 text-sm">Powered by Optiverse Ai Agency & Sports Analytics</p>
      </div>
    </footer>
  );
};

export default Footer;
