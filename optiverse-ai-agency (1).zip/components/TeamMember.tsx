
import React from 'react';
import { TeamMemberProps } from '../types';

const TeamMember: React.FC<TeamMemberProps> = ({ name, role, expertise }) => {
  return (
    <div className="text-center bg-custom-gray-700/50 p-6 rounded-lg hover:bg-custom-gray-700 transition-colors">
      <div className="w-20 h-20 bg-custom-gray-600 rounded-full mx-auto mb-4 flex items-center justify-center ring-2 ring-custom-blue-500" aria-hidden="true">
        <svg className="w-10 h-10 text-custom-blue-400" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M20 21V19C20 16.7909 18.2091 15 16 15H8C5.79086 15 4 16.7909 4 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h4 className="font-bold text-lg text-white">{name}</h4>
      <div className="text-custom-blue-400 text-sm mb-1">{role}</div>
      <div className="text-xs text-custom-gray-400">{expertise}</div>
    </div>
  );
};

export default TeamMember;