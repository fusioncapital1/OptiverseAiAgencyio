import React, { useState } from 'react';
import { PickItem, ParlayStats, ActiveTab, Sport } from '../types';

interface ParlayScreenProps {
  selections: PickItem[];
  stats: ParlayStats;
  onRemove: (pick: PickItem) => void;
  onClearAll: () => void;
  setActiveTab: (tab: ActiveTab) => void;
}

// Re-importing SportIcons or defining them if not available globally via props
const SportIcons: Record<Sport, React.ReactNode> = {
    NBA: <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93s3.05-7.44 7-7.93v15.86zm2-15.86c1.03.13 2 .45 2.87.93H13v-.93zm0 3h1.45c.32.3.59.64.81 1H13v-1zm0 3h2.03c.05.33.07.66.07 1s-.02.67-.07 1H13v-2zm0 3h1.82c-.24.4-.55.75-.91 1.03H13v-1.03zm0 3h.87c-.87.48-1.84.8-2.87.93V17h2z"></path></svg>,
    NFL: <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v2h-2v-2zm0 4h2v6h-2v-6z"></path></svg>,
    MLB: <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-3.5-9.5L12 14l3.5-3.5L12 7l-3.5 3.5z"></path></svg>,
    WNBA: <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M21.64 5.13c-.2-.25-.52-.39-.86-.39H3.22c-.34 0-.66.14-.86.39-.2.25-.28.59-.2.91L4.5 18.27c.15.61.68 1.02 1.31 1.02h12.38c.63 0 1.16-.41 1.31-1.02l2.34-12.23c.08-.32 0-.66-.2-.91zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z"></path></svg>,
};

const ParlayScreen: React.FC<ParlayScreenProps> = ({ selections, stats, onRemove, onClearAll, setActiveTab }) => {
  const [wager, setWager] = useState<string>('');

  const calculatePotentialPayout = () => {
    if (!wager || selections.length < 2 || !stats.totalOdds || stats.totalOdds === '-') return '0.00';
    const numericWager = parseFloat(wager);
    if (isNaN(numericWager) || numericWager <= 0) return '0.00';
    const americanOddsStr = stats.totalOdds.replace('+', '');
    const americanOdds = parseFloat(americanOddsStr);
    if (isNaN(americanOdds)) return '0.00';
    let decimalOdds: number;
    if (americanOdds > 0) decimalOdds = (americanOdds / 100) + 1;
    else decimalOdds = (100 / Math.abs(americanOdds)) + 1;
    return (numericWager * decimalOdds).toFixed(2);
  };
  
  const potentialPayout = calculatePotentialPayout();

  return (
    <div aria-labelledby="parlay-screen-heading">
      <h2 id="parlay-screen-heading" className="text-3xl font-bold mb-8 text-white">Parlay Builder</h2>
      
      {selections.length === 0 ? (
        <div className="bg-custom-gray-800 rounded-xl p-8 text-center shadow-xl border border-custom-gray-700">
          <svg className="w-20 h-20 mx-auto text-custom-gray-600 mb-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M12 4.5C11.7239 4.5 11.5 4.72386 11.5 5V11.5H5C4.72386 11.5 4.5 11.7239 4.5 12C4.5 12.2761 4.72386 12.5 5 12.5H11.5V19C11.5 19.2761 11.7239 19.5 12 19.5C12.2761 19.5 12.5 19.2761 12.5 19V12.5H19C19.2761 12.5 19.5 12.2761 19.5 12C19.5 11.7239 19.2761 11.5 19 11.5H12.5V5C12.5 4.72386 12.2761 4.5 12 4.5Z" fill="currentColor"/>
            <path d="M12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2ZM12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5Z" fill="currentColor"/>
          </svg>
          <h3 className="text-2xl font-semibold mb-3 text-white">Your Parlay is Empty</h3>
          <p className="text-custom-gray-400 mb-8">Add at least two sharp picks from our AI to build your winning parlay!</p>
          <button 
            onClick={() => setActiveTab('picks')}
            className="bg-custom-blue-600 hover:bg-custom-blue-700 text-white font-semibold py-3 px-8 rounded-lg shadow-lg hover:shadow-custom-blue-500/50 transition-all transform hover:scale-105"
          >
            Explore AI Picks
          </button>
        </div>
      ) : (
        <div className="grid lg:grid-cols-5 gap-6">
          <section className="lg:col-span-3 bg-custom-gray-800 rounded-xl shadow-xl border border-custom-gray-700" aria-labelledby="your-parlay-heading">
            <div className="p-5 border-b border-custom-gray-700 flex justify-between items-center">
              <h3 id="your-parlay-heading" className="text-xl font-bold text-white">Your Parlay ({selections.length} Leg{selections.length === 1 ? '' : 's'})</h3>
              <button onClick={onClearAll} disabled={selections.length === 0} className="flex items-center text-sm text-custom-red-400 hover:text-red-300 font-medium py-1.5 px-3 rounded-md hover:bg-red-500/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed" aria-label="Clear all parlay selections">
                <svg className="w-4 h-4 mr-1.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12.56 0c1.153 0 2.243.032 3.223.094M15 3.75V2.25A2.25 2.25 0 0 0 12.75 0h-1.5A2.25 2.25 0 0 0 9 2.25v1.5" /></svg>
                Clear All
              </button>
            </div>
            
            <div className="divide-y divide-custom-gray-700 max-h-[500px] overflow-y-auto custom-scrollbar p-2">
              {selections.map((pick) => (
                <div key={pick.id} className="p-4 hover:bg-custom-gray-700/40 transition-colors rounded-md">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-custom-gray-400" aria-label={pick.sport}>{pick.sportIcon || SportIcons[pick.sport]}</span>
                        <span className="text-xs font-medium text-custom-gray-400">{pick.sport.toUpperCase()}</span>
                      </div>
                      <div className="font-semibold text-white text-md">{pick.teams}</div>
                      <div className="text-sm text-custom-blue-400">{pick.prediction}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-yellow-400">{pick.odds}</div>
                       <button onClick={() => onRemove(pick)} aria-label={`Remove ${pick.teams} from parlay`} className="mt-1 text-xs text-custom-red-400 hover:text-red-300 font-medium py-1 px-2 rounded hover:bg-red-500/10 transition-all">
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
          
          <aside className="lg:col-span-2 bg-custom-gray-800 rounded-xl shadow-xl border border-custom-gray-700 p-6 flex flex-col" aria-labelledby="parlay-summary-heading">
            <h3 id="parlay-summary-heading" className="text-2xl font-bold mb-6 text-white text-center">Parlay Bet Slip</h3>
            
            <div className="space-y-5 mb-6 flex-grow">
              <div className="bg-custom-gray-700/70 p-4 rounded-lg text-center">
                <label htmlFor="total-odds" className="text-xs text-custom-gray-300 uppercase tracking-wider">Total Parlay Odds</label>
                <div id="total-odds" className="text-3xl font-bold text-custom-blue-400 mt-1" aria-live="polite">{stats.totalOdds}</div>
              </div>
              
              <div className="bg-custom-gray-700/70 p-4 rounded-lg text-center">
                 <label htmlFor="combined-probability" className="text-xs text-custom-gray-300 uppercase tracking-wider">Est. Combined Probability</label>
                <div id="combined-probability" className="text-3xl font-bold text-custom-green-400 mt-1" aria-live="polite">{stats.totalProbability}</div>
              </div>
              
              <div>
                <label htmlFor="wager-amount" className="text-sm text-custom-gray-300 block mb-1.5 font-medium">Wager Amount</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-custom-gray-400 text-xl">$</span>
                  <input id="wager-amount" type="number" placeholder="0.00" value={wager} onChange={(e) => setWager(e.target.value)} className="w-full bg-custom-gray-900 border-2 border-custom-gray-700 rounded-lg pl-8 pr-3 py-3 text-white text-xl font-semibold focus:border-custom-blue-500 focus:ring-2 focus:ring-custom-blue-500/50 outline-none transition-colors" aria-describedby="wager-help" min="0" step="0.01"/>
                </div>
                <p id="wager-help" className="sr-only">Enter your wager amount in dollars.</p>
              </div>

               <div className="bg-custom-gray-900/50 border-2 border-custom-gray-700 p-4 rounded-lg text-center">
                <label htmlFor="potential-payout" className="text-sm text-custom-gray-300 uppercase tracking-wider block mb-1">Potential Payout</label>
                <div id="potential-payout" className="text-4xl font-bold text-yellow-400" aria-live="polite">${potentialPayout}</div>
              </div>
            </div>
            
            <button onClick={() => alert(`Disclaimer: This is a simulation. If this were real, you'd be placing a parlay bet with a $${wager || '0.00'} wager for a potential payout of $${potentialPayout}. Always gamble responsibly.`)} className="w-full bg-custom-green-500 hover:bg-custom-green-600 text-white font-bold py-4 px-4 rounded-lg transition-all shadow-lg hover:shadow-custom-green-500/50 text-lg disabled:opacity-60 disabled:cursor-not-allowed" disabled={selections.length < 2 || !wager || parseFloat(wager) <= 0}>
              Place Parlay Bet
            </button>
             <p className="text-xs text-custom-gray-500 mt-3 text-center">Requires at least 2 picks and a valid wager.</p>
          </aside>
        </div>
      )}
    </div>
  );
};

export default ParlayScreen;