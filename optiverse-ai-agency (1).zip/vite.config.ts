
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const apiKeyFromEnv = process.env.API_KEY;
  const stripePublishableKeyFromEnv = process.env.STRIPE_PUBLISHABLE_KEY;
  const ellaN8nWebhookUrlFromEnv = process.env.ELLA_N8N_WEBHOOK_URL;
  const contactFormN8nWebhookUrlFromEnv = process.env.CONTACT_FORM_N8N_WEBHOOK_URL; // Added

  if (!apiKeyFromEnv && mode === 'production') {
    console.warn('PRODUCTION BUILD WARNING: API_KEY environment variable is not set. AI features will be disabled or fail.');
  }
  if (!stripePublishableKeyFromEnv && mode === 'production') {
    console.warn('PRODUCTION BUILD WARNING: STRIPE_PUBLISHABLE_KEY environment variable is not set. Stripe features will be disabled or fail.');
  }
  if (!ellaN8nWebhookUrlFromEnv && mode === 'production') {
    console.warn('PRODUCTION BUILD WARNING: ELLA_N8N_WEBHOOK_URL environment variable is not set. Ella chat features will be disabled or use mock responses.');
  }
  if (!contactFormN8nWebhookUrlFromEnv && mode === 'production') { // Added check
    console.warn('PRODUCTION BUILD WARNING: CONTACT_FORM_N8N_WEBHOOK_URL environment variable is not set. Contact form features will be disabled or use mock responses.');
  }


  return {
    plugins: [react()],
    define: {
      'process.env.API_KEY': JSON.stringify(apiKeyFromEnv || ''),
      'process.env.STRIPE_PUBLISHABLE_KEY': JSON.stringify(stripePublishableKeyFromEnv || ''),
      'process.env.ELLA_N8N_WEBHOOK_URL': JSON.stringify(ellaN8nWebhookUrlFromEnv || 'YOUR_ELLA_N8N_WEBHOOK_URL_PLACEHOLDER'),
      'process.env.CONTACT_FORM_N8N_WEBHOOK_URL': JSON.stringify(contactFormN8nWebhookUrlFromEnv || 'YOUR_CONTACT_FORM_N8N_WEBHOOK_URL_PLACEHOLDER'), // Added
    },
  }
})