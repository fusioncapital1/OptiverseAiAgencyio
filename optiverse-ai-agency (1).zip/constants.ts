
import { PickItem } from './types';

// Fix: Added gameDate to each PickItem
const sampleGameDate = new Date().toISOString();

export const DAILY_FREE_PICK_LIMIT = 3; // Number of free AI picks per day for non-subscribed users

export const SAMPLE_PICKS: PickItem[] = [
  {
    id: 1,
    sport: 'NBA',
    teams: 'Lakers vs Warriors',
    prediction: 'Lakers to win by +5.5',
    probability: '72%',
    odds: '+145',
    parlayOptions: ['Moneyline', 'Spread', 'Over/Under'],
    gameDate: sampleGameDate, // Added gameDate
  },
  {
    id: 2,
    sport: 'NFL',
    teams: 'Chiefs vs Buccaneers',
    prediction: 'Chiefs -3.5 ATS',
    probability: '68%',
    odds: '+120',
    parlayOptions: ['ATS', 'Total Points Over 48.5'],
    gameDate: sampleGameDate, // Added gameDate
  },
  {
    id: 3,
    sport: 'MLB',
    teams: 'Yankees vs Red Sox',
    prediction: 'Under 9.5 Runs',
    probability: '63%',
    odds: '+110',
    parlayOptions: ['Under', 'Yankees ML'],
    gameDate: sampleGameDate, // Added gameDate
  },
  // Fix: Changed sport from 'NHL' to 'WNBA' to match the Sport type and updated related fields
  {
    id: 4,
    sport: 'WNBA', // Corrected sport type
    teams: 'Aces vs Liberty', // Updated teams for WNBA
    prediction: 'Aces to win', // Updated prediction
    probability: '65%',
    odds: '+130',
    parlayOptions: ['Moneyline', 'Total Points Under 165.5'], // Updated parlay options
    gameDate: sampleGameDate, // Added gameDate
  },
];