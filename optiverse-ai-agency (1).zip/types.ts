import React from 'react';

export type Sport = "NBA" | "NFL" | "MLB" | "WNBA"; // Added WNBA

export interface PickItem {
  id: number; // Unique identifier for the pick
  sport: Sport; // e.g., "NBA", "NFL", "MLB", "WNBA"
  teams: string; // e.g., "Lakers vs Warriors"
  prediction: string; // AI's prediction
  probability: string; // AI's confidence
  odds: string; // Suggested odds
  parlayOptions: string[]; // Available parlay options for this pick
  gameDate: string; // ISO string for the game date/time for sorting and display
  sportIcon?: React.ReactNode; // Optional: For displaying a sport-specific icon
}

export interface ParlayStats {
  totalOdds: string;
  totalProbability: string;
}

export type ActiveTab = 'home' | 'picks' | 'parlay' | 'about';

export interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface StepCardProps {
  number: string;
  title: string;
  description: string;
}

export interface TeamMemberProps {
  name: string;
  role: string;
  expertise: string;
}

// Internal App Structures for API Game Data
export interface ApiGameTeam {
  id: number; // Unique ID for the team
  name: string;
  logo?: string; // Optional logo URL
}

export interface ApiGameLeague {
  id: number; // Unique ID for the league (e.g., 1 for NBA, 2 for NFL)
  name: Sport; // e.g., "NBA", "NFL"
  logo?: string; // Optional logo URL
  season?: number | string; // e.g., 2023 or "2023-2024"
}

export interface ApiGameScore {
  home: number | null;
  away: number | null;
}

export interface ApiGame {
  id: number; // Unique ID for the game (must be unique across all sports)
  league: ApiGameLeague;
  teams: {
    home: ApiGameTeam;
    away: ApiGameTeam;
  };
  date: string; // ISO string date
  status?: { long?: string; short?: string }; // e.g., "FT", "SCH" (Scheduled)
  scores?: ApiGameScore;
}