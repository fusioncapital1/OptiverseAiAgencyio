
import { loadStripe, Stripe } from '@stripe/stripe-js';

let stripePromise: Promise<Stripe | null>;
const STRIPE_PUBLISHABLE_KEY = process.env.STRIPE_PUBLISHABLE_KEY;

export const getStripe = (): Promise<Stripe | null> => {
  if (!STRIPE_PUBLISHABLE_KEY) {
    console.error("Stripe publishable key is not set in environment variables (STRIPE_PUBLISHABLE_KEY). Stripe functionality will be disabled.");
    return Promise.resolve(null);
  }
  if (!stripePromise) {
    stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);
  }
  return stripePromise;
};

export const handleSubscriptionCheckout = async () => {
  if (!STRIPE_PUBLISHABLE_KEY) {
    alert("Stripe is not configured. Payment cannot be processed. Please ensure STRIPE_PUBLISHABLE_KEY is set.");
    return { error: "Stripe publishable key not configured." };
  }

  const stripe = await getStripe();
  if (!stripe) {
    alert("Stripe failed to initialize. Payment cannot be processed.");
    return { error: "Stripe failed to initialize." };
  }

  // IMPORTANT: Replace 'price_YOUR_799_RECURRING_MONTHLY_PRICE_ID' with the actual Price ID
  // from a $7.99/month recurring Price object in your Stripe dashboard.
  const subscriptionPriceId = 'price_1RSWIbLSIMfBxWKWKBK8fMEIk'; // Updated with your Price ID

  // Fix: Removed the 'if' block that checked for 'price_YOUR_799_RECURRING_MONTHLY_PRICE_ID'.
  // This check was redundant as the subscriptionPriceId has been updated,
  // and the comparison would always be false, causing the TypeScript error.

  try {
    console.log("Attempting to redirect to Stripe Checkout with Price ID:", subscriptionPriceId);
    console.log("Success URL:", `${window.location.origin}?stripe_session_status=success&session_id={CHECKOUT_SESSION_ID}`);
    console.log("Cancel URL:", `${window.location.origin}?stripe_session_status=cancelled`);

    const { error } = await stripe.redirectToCheckout({
      lineItems: [{ price: subscriptionPriceId, quantity: 1 }],
      mode: 'subscription',
      successUrl: `${window.location.origin}?stripe_session_status=success&session_id={CHECKOUT_SESSION_ID}`,
      cancelUrl: `${window.location.origin}?stripe_session_status=cancelled`,
    });

    if (error) {
      console.error("Stripe redirectToCheckout error:", error);
      alert(`Error redirecting to Stripe: ${error.message}`);
      return { error: error.message };
    }
    return { success: true };

  } catch (e) {
    const err = e as Error;
    console.error("Exception during Stripe checkout process:", err);
    alert(`An unexpected error occurred during checkout: ${err.message}`);
    return { error: err.message };
  }
};